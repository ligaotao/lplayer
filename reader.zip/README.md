# lplayer

> A React project

## Usage

```bash
# install all this dependencies.
npm install

# development, default port: 8080
npm run dev

# production
npm run build

# lint the files
npm run lint

```
