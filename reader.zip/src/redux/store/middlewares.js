import { applyMiddleware } from 'redux'

export default applyMiddleware(
  // you can apply you middleware here
)
