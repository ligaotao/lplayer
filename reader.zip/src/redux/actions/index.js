import * as types from '../constants/ActionTypes'

export const increment = () => ({ type: types.INCREMENT })
