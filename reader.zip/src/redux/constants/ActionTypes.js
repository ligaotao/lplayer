export const INCREMENT = 'INCREMENT'
